#!/bin/bash
# ProkaRegia Snakemake Runner Script

# Display usage
usage() {
    echo "ProkaRegia Snakemake Pipeline Runner"
    echo ""
    echo "Usage: $0 -i INPUT_FASTQ -s SEQ_TECH [OPTIONS]"
    echo ""
    echo "Required arguments:"
    echo "  -i, --input       Path to input FASTQ file"
    echo "  -s, --seq-tech    Sequencing technology: 'ont' or 'pacbio'"
    echo ""
    echo "Optional arguments:"
    echo "  -o, --output      Output directory name (default: ProkaRegia)"
    echo "  -t, --threads     Number of threads (default: 8)"
    echo "  -n, --dry-run     Show what would be executed without running"
    echo "  -h, --help        Display this help message"
    echo ""
    echo "Examples:"
    echo "  $0 -i reads.fastq -s ont -t 16"
    echo "  $0 -i data/pacbio.fastq -s pacbio -o MyOutput -t 32"
    echo "  $0 -i reads.fastq -s ont -n  # Dry run"
    exit 1
}

# Default values
OUTPUT="ProkaRegia"
THREADS=8
DRY_RUN=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -i|--input)
            INPUT="$2"
            shift 2
            ;;
        -s|--seq-tech)
            SEQ_TECH="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT="$2"
            shift 2
            ;;
        -t|--threads)
            THREADS="$2"
            shift 2
            ;;
        -n|--dry-run)
            DRY_RUN="-n"
            shift
            ;;
        -h|--help)
            usage
            ;;
        *)
            echo "Unknown option: $1"
            usage
            ;;
    esac
done

# Validate required arguments
if [ -z "$INPUT" ] || [ -z "$SEQ_TECH" ]; then
    echo "Error: Missing required arguments"
    usage
fi

if [ ! -f "$INPUT" ]; then
    echo "Error: Input file not found: $INPUT"
    exit 1
fi

if [ "$SEQ_TECH" != "ont" ] && [ "$SEQ_TECH" != "pacbio" ]; then
    echo "Error: Sequencing technology must be 'ont' or 'pacbio'"
    exit 1
fi

# Get absolute path
INPUT=$(readlink -f "$INPUT")

# Update config file
echo "Updating configuration..."
cat > config.yaml << EOF
# ProkaRegia Pipeline Configuration (auto-generated)

input_fastq: "$INPUT"
output_dir: "$OUTPUT"
seq_tech: "$SEQ_TECH"
threads: $THREADS
EOF

echo "Configuration:"
echo "  Input:     $INPUT"
echo "  Output:    $OUTPUT"
echo "  Seq Tech:  $SEQ_TECH"
echo "  Threads:   $THREADS"
echo ""

# Check if snakemake is available
if ! command -v snakemake &> /dev/null; then
    echo "Error: snakemake not found. Please install or activate snakemake environment."
    echo "  conda activate snakemake"
    exit 1
fi

# Run snakemake
if [ -n "$DRY_RUN" ]; then
    echo "Running dry-run..."
    snakemake --use-conda -n
else
    echo "Starting pipeline..."
    snakemake --use-conda --cores "$THREADS"
fi
